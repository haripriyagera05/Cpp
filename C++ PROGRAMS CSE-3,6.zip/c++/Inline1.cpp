//Example for inline functions 
#include<iostream>
using namespace std;
inline void printhello()
{ 
cout<<"Hello"<<endl;
}
int main()
{
	printhello(); // cout<<"Hello"<<endl;
	printhello(); // cout<<"Hello"<<endl;
	  return 0; 
}
