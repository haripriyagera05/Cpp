#include<iostream>
using namespace std;

int square( int x)
{ 
return x*x;
}
int main()
{
	
	cout<<"Square ="<<square(7)<<endl;
	
	return 0;
}
