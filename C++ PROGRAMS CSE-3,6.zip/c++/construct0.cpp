#include<iostream>
using namespace std;
class example{
	public : example()
	{
		 cout<<"this is constructor......"<<endl;
	}
};
int main()
{
	  example one;
	  return 0; 
}
