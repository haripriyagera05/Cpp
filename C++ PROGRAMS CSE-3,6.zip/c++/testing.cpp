#include<iostream>
using namespace std;
int x=20;
class A 
{
	 int a=10;
	 void print()
	 { cout<<"a= "<<a<<endl;}
};

int main()
{
	  int x=10; 
	  cout<<" x = "<<x<<endl;
}
